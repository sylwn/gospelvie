<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Cromax add a new pagebuilder section
 *
 *
 * @package Cromatic
 * @subpackage Cromatic
 * @since 1.0
 */



$ttury = cro_identifyvideo($namearray[0], 0);


?>

<div class="croma-vdo">
	<div class="flex-video vimeo widescreen">
	<?php echo $ttury['frame']; ?>
	</div>
</div>





